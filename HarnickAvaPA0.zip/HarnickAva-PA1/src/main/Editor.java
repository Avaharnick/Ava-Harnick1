/**
* This class constructs an editor using a link list, and creates methods that can be used on the editor.
* Known Bugs: None
*
* @author Ava Harnick
* avaharnick@brandeis.edu
* Oct 6, 2020
* COSI 21A PA1
*/



package main;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Editor {
	
	public int numChars; /** KEEP THIS PUBLIC : use this to store the number of characters in your Editor */
	public int curPos; /** KEEP THIS PUBLIC : use this to store the current cursor index in [0, numChars] */
	
	public Node cur; /** KEEP THIS PUBLIC : use this to reference the node that is after the visual cursor or null if curPos = numChars */
	public Node head; /** KEEP THIS PUBLIC : use this to reference the first node in the Editor's doubly linked list */
	public Node tail; /** KEEP THIS PUBLIC : use this to reference the last node in the Editor's doubly linked list */
	
	public Stack<String> savedVersions; /** KEEP THIS PUBLIC : use this to store the contents of the editor that are saved by the user */
	/**
	 * This method constructs the editor if no file is passed into it 
	 */
	 
	public Editor() {//Run time: O(1)
		this.numChars=0;
		this.curPos=0;
		this.cur=null;
		this.head=null;
		this.tail=null;
		this.savedVersions=new Stack<String>();
	}
	/**
	 * This method constructs the editor if a file is passed into it. 
	 * @param filepath, a file that will be stored in this editor 
	 * @throws FileNotFoundException
	 */
	public Editor(String filepath) throws FileNotFoundException {//Run time : O(n)
		savedVersions=new Stack<>();
		File file= new File(filepath);
		Scanner input= new Scanner(file);
		String firstLine=input.nextLine();
		String entireFile=firstLine+"\n";
		while (input.hasNextLine()) {
			entireFile=entireFile+input.nextLine();	
			if(input.hasNextLine()) {
				entireFile=entireFile+"\n";
			}
		}
		
		 putIntoList(entireFile);
	}
	/**
	 * This method puts the string passed into it into a linked list 
	 * @param s, a string that will be put into a linked list 
	 */
	public void putIntoList(String s) {//Run time : O(n)
		String entireFile=s;
		if(entireFile.length()>0) {
			char firstChar=entireFile.charAt(0);    
			Node node= new Node(firstChar);
			this.head=node;
			head.prev=null;
			Node prev=head;
			for(int i=1;i<entireFile.length();i++) {
				Node newNode=new Node(entireFile.charAt(i));
				newNode.prev=prev;
				prev.next=newNode;
				prev=newNode;
			}
			prev.next=null;
			this.tail=prev;
			this.cur=head;
			this.curPos=0;
			this.numChars=entireFile.length();
		}else {
			this.numChars=0;
			this.curPos=0;
			this.cur=null;
			this.head=null;
			this.tail=null;
		}
			
	}
		
	/**
	 * This method returns the position of the curser 
	 * @return curPos, the position of the curser 
	 */
	public int getCursorPosition() {//Run time O(1)
		return curPos;
	}
	/**
	 * This method returns the size of the linked list
	 * @return numChars, the amount of characters stored in the linked list 
	 */
	public int size() {//Run time O(1)
		return numChars;
	}
	/**
	 * This method moves the cursor right by one position 
	 */
	public void moveRight() {//Run time O(1)
		if(curPos<numChars) { 
			cur=cur.next;
			curPos++;  
		}
	}
	/**
	 * This method moves the curser left by one position 
	 */
	public void moveLeft() {//Run time O(1)
		if(cur==null) {
			cur=tail;
			curPos--;
		}
		else if(curPos>0&&cur!=null) {
			cur=cur.prev;
			curPos--;
		}
	}
	/**
	 * This method moves moves the curser to the head of the linked list 
	 */
	public void moveToHead() {//Run time O(1)
		cur=head;
		curPos=0;
	}
	/**
	 * This method moves the curser to the tail of the linked list 
	 */
	public void moveToTail() {//Run time O(1)
		cur=tail.next;    
		curPos=numChars;
	}
	/**
	 * This method inserts a new character into the linked list 
	 * @param c, a character that will inserted into the linked list  
	 */
	public void insert(char c) {//Run time O(1)
		Node node=new Node(c);
		if(numChars==0) {
			head=node;
			tail=node;
			cur=null;
			
		}
		else if(cur!=null&&cur.equals(head)) {
			node.next=head;
			head.prev=node;
			head=node;
		}
		else if(cur==null) {
			node.prev=tail;
			tail.next=node;
			tail=node;
		}
		
		else {
			Node prev=cur.prev;
			node.prev=prev;
			prev.next=node;
			cur.prev=node;  
			node.next=cur;
			prev=node;
			
		}
		
		curPos++;
		numChars++;
		
	}
	/**
	 * This method deletes cur from the linked list 
	 */
	public void delete() {//Run time: O(1)
		
		
		if(numChars>0&&cur!=null) {
			
			if(cur.equals(head)&&cur.next!=null) { 
				Node next=cur.next;
				next.prev=null;
				head=next;	
				numChars--;
				cur=next;
				}
			else if(cur.equals(head)&&cur.equals(tail)) {
				cur=null;
				head=null;
				tail=null;
				numChars--;
			}
			else if(cur.equals(tail)) {
				Node prev=cur.prev;
				prev.next=null;
				tail=prev;
				numChars--;
				cur=null;
			}
			else {
				Node prev=cur.prev;
				Node next=cur.next;
				prev.next=next;
				next.prev=prev;
				numChars--;
				cur=next;
			}
			
		}
		
		
		
		
		}
		/**
		 * This method removes the node before cur from the linked list 
		 */
	public void backspace() {//Run time: O(1)
		if (cur==null&&numChars>1) {
			Node prev=tail.prev;
			prev.next=null;
			tail.prev=null;
			tail=prev;
			curPos--;
			numChars--;
		}else if((cur==null)&&numChars==1) {
			head=null;
			tail=null;
			curPos--;
			numChars--;
		}
		else if(cur!=null&&cur!=head&&numChars>0) {
			Node del=cur.prev;
			if(del.equals(head)) {
				cur.prev=null;
				head=cur;
				curPos--;
				numChars--;
			}
			else {
				Node prev=cur.prev.prev;
				prev.next=cur;
				cur.prev=prev;
				curPos--;
				numChars--;
			}
		}
		
		
		
		 
	}
	/**
	 * This method takes turns the linked list into a string 
	 * @return s, the the string that contains all the character that were in the linked list 
	 */
	public String toString() {//Run time: O(n)
		String s="";
		if(numChars<1) {
			s="";
		}
		else {
			Node node=head;
			s="";
			while(node!=null) {
				s=s+node.data;
				node=node.next;
		}
		
		}
		return s;
	}
	/**
	 * This method clears all of the elements in the linked list 
	 */
	public void clear() { //Run time: O(1)
		head=null; 
		tail=null;
		numChars=0;
		cur=null;
		curPos=0;
	}
	/**
	 * This file exports the characters in the linked list to a file
	 * @param savepath, this file will be exported and contain all of the characters in the linked list
	 * @throws FileNotFoundException
	 */
	public void export(String savepath) throws FileNotFoundException {//Run time: O(n)
		File f=new File(savepath);
		PrintStream ex=new PrintStream(f);
		ex.print(toString());
	}
	/**
	 * This method saves the current version of the editor 
	 */
	public void save() {//Run time: O(n)          
		String s=toString();   
		if(!s.equals(savedVersions.top())) {
			savedVersions.push(s);
		}
			
	}
	/**
	 * This method reverts the editor to the most recently saved of its self
	 */
	public void undo() {//Run time: O(1)
		String s="";
		if (!savedVersions.isEmpty()) {   
			s=savedVersions.pop();
			putIntoList(s); 
		}
		
		
		
	}
	
}
