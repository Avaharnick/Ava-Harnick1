/**
* This class constructs a stack using an array.This stack is used to store saved versions of the editor
* Known Bugs: None
*                     
* @author Ava Harnick
* avaharnick@brandeis.edu
* Oct 6, 2020
* COSI 21A PA1
*/    
package main;

public class Stack<T> {

	public T[] stack;
	private int size;
	private int stackSize;

	@SuppressWarnings("unchecked")
	public Stack() {//Run time: O(1)
		this.stack = (T[]) new Object[10];
		size=0;
		stackSize=stack.length;
	}
	/**
	 * This method places elements x on the top of the stack 
	 * @param x, an element that gets pushed to the stack
	 */
	public void push(T x) {//Run time: O(n)
		if(size<stack.length) {
			stack[size]=x;
			size++;
		}
		else {
			T[] copy=(T[]) new Object[stackSize+5];
			for(int i=0;i<size;i++) {
				copy[i]=stack[i];
			}
			stack=copy;
			stack[size]=x;
			size++;
			stackSize=stack.length;
		}
	}
	/**
	 * This method returns and removes the element at the top of the stack 
	 * @return element, the element at the top of the stack
	 */
	public T pop() {//Run time: O(1)
	T element = null;
	if(!isEmpty()) {
		element=stack[size-1];
		size--; 
	}else {
		throw new IllegalStateException("Empty Stack");
	}
	
		return element;
	}
	/**
	 * This method returns the element at the top of the stack without removing it 
	 * @return element, the element at the top of the stack 
	 */
	public T top() {
		T element=null;
		if(!isEmpty()) {//Run time: O(1)
			element=stack[size-1];
		}
		return element;
	}
	/**
	 * This method returns the element at the top of the stack 
	 * @return size, the number of elements in the stack
	 */
	public int size() {//Run time: O(1)
		
		return size;
	}
	/**
	 * This method returns true if the list is empty and false if it is not 
	 * @return boolean, true or false
	 */
	public boolean isEmpty() {//Run time: O(1)
		
		if (size()>0){
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * This method returns the elements in the stack as a concatenated string 
	 * @return s, the elements of the stack as a string 
	 */
	public String toString() {//Run time: O(n)
		String s="";
		for (int i=0;i<size;i++) {
			s=stack[i]+"\n"+s;
					
		}
		return s;
	}
	
}
