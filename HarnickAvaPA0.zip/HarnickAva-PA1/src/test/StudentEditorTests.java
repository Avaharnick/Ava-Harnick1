package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;
import main.Node;
import main.Stack;
import main.Editor;

class StudentEditorTests {

	@Test
	void puIntoListTest() {
		Editor editor=new Editor();
		String s="This is a test";
		editor.putIntoList(s);
		assertEquals(editor.head.data,'T');
		assertEquals(editor.tail.data,'t');
		assertEquals(editor.cur.data,'T');
		Node second=editor.head.next;
		assertEquals(second.data,'h');
		Node third=second.next;
		assertEquals(third.data,'i');
		Node fourth=third.next;
		assertEquals(fourth.data,'s');
		Node fifth=fourth.next;
		assertEquals(fifth.data,' ');
		Node sixth=fifth.next;
		assertEquals(sixth.data,'i');
		Node seventh=(sixth.next);
		assertEquals(seventh.data,'s');
		Node eigth=(seventh.next);
		assertEquals(eigth.data,' ');
		Node nineth=(eigth.next);
		assertEquals(nineth.data,'a');
		Node tenth=(nineth.next);
		assertEquals(tenth.data,' ');
		Node eleventh=(tenth.next);
		assertEquals(eleventh.data,'t');
		Node tweleve=(eleventh.next);
		assertEquals(tweleve.data,'e');
		Node thirteen=(tweleve.next);
		assertEquals(thirteen.data,'s');
		assertEquals(editor.curPos,0);
		assertEquals(editor.numChars,14);
	}
	@Test
	void constructorSingleLineTest() throws FileNotFoundException {
		Editor editor=new Editor ("single_line_file.txt");
		assertEquals(editor.head.data,'I');
		//assertEquals(editor.tail.data,'.');
		assertEquals(editor.cur.data,'I');
		Node second=editor.head.next;
		assertEquals(second.data,' ');
		Node third=second.next;
		assertEquals(third.data,'a');
		Node fourth=third.next;
		assertEquals(fourth.data,'m');
		Node fifth=fourth.next;
		assertEquals(fifth.data,' ');
		Node sixth=fifth.next;
		assertEquals(sixth.data,'a');
		Node seventh=(sixth.next);
		assertEquals(seventh.data,' ');
		Node eigth=(seventh.next);
		assertEquals(eigth.data,'s');
		Node nineth=(eigth.next);
		assertEquals(nineth.data,'i');
		Node tenth=(nineth.next);
		assertEquals(tenth.data,'n');
		Node eleventh=(tenth.next);
		assertEquals(eleventh.data,'g');
		Node tweleve=(eleventh.next);
		assertEquals(tweleve.data,'l');
		Node thirteen=(tweleve.next);
		assertEquals(thirteen.data,'e');
		Node fourteen=(thirteen.next);
		assertEquals(fourteen.data,' ');
		Node fifteen=(fourteen.next);
		assertEquals(fifteen.data,'l');
		Node sixteen=(fifteen.next);
		assertEquals(sixteen.data,'i');
		Node seventeen=(sixteen.next);
		assertEquals(seventeen.data,'n');
		Node eighteen=(seventeen.next);
		assertEquals(eighteen.data,'e');
		Node nineteen=(eighteen.next);
		assertEquals(nineteen.data,' ');
		Node twenty=(nineteen.next);
		assertEquals(twenty.data,'f');
		Node twenty1=(twenty.next);
		assertEquals(twenty1.data,'i');
		Node twenty2=(twenty1.next);
		assertEquals(twenty2.data,'l');
		Node twenty3=(twenty2.next);
		assertEquals(twenty3.data,'e');
		
	}
	
	@Test
	void constructorMultiLineTest() throws FileNotFoundException {
		Editor editor=new Editor ("multi_line_file.txt");
		assertEquals(editor.head.data,'I');
		assertEquals(editor.tail.data,'.');
		assertEquals(editor.cur.data,'I');
		Node second=editor.head.next;
		assertEquals(second.data,' ');
		Node third=second.next;
		assertEquals(third.data,'a');
		Node fourth=third.next;
		assertEquals(fourth.data,'m');
		Node fifth=fourth.next;
		assertEquals(fifth.data,' ');
		Node sixth=fifth.next;
		assertEquals(sixth.data,'a');
		Node seventh=(sixth.next);
		assertEquals(seventh.data,'\n');
		Node eigth=(seventh.next);
		assertEquals(eigth.data,'m');
		Node nineth=(eigth.next);
		assertEquals(nineth.data,'u');
		Node tenth=(nineth.next);
		assertEquals(tenth.data,'l');
		Node eleventh=(tenth.next);
		assertEquals(eleventh.data,'t');
		Node tweleve=(eleventh.next);
		assertEquals(tweleve.data,'i');
		Node thirteen=(tweleve.next);
		assertEquals(thirteen.data,'l');
		Node fourteen=(thirteen.next);
		assertEquals(fourteen.data,'i');
		Node fifteen=(fourteen.next);
		assertEquals(fifteen.data,'n');
		Node sixteen=(fifteen.next);
		assertEquals(sixteen.data,'e');
		Node seventeen=(sixteen.next);
		assertEquals(seventeen.data,'\n');
		Node eighteen=(seventeen.next);
		assertEquals(eighteen.data,'f');
		Node nineteen=(eighteen.next);
		assertEquals(nineteen.data,'i');
		Node twenty=(nineteen.next);
		assertEquals(twenty.data,'l');
		Node twenty1=(twenty.next);
		assertEquals(twenty1.data,'e');
	}
	
	

	@Test
	void putIntoListTestOneChar() {
		Editor editor=new Editor();
		String s="a";
		editor.putIntoList(s);
		assertEquals(editor.head.data,'a');
		assertEquals(editor.tail.data,'a');
		assertEquals(editor.cur.data,'a');
		assertEquals(editor.curPos,0);
		assertEquals(editor.numChars,1);
	}
	@Test
	void puIntoListTestempty() {
		Editor editor=new Editor();
		String s="";
		editor.putIntoList(s);
		assertEquals(editor.head,null);
		assertEquals(editor.tail,null);
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,0);
		assertEquals(editor.numChars,0);
	}
	
	@Test
	void moveRightTest() {
		Editor editor=new Editor();
		String s="test";
		editor.putIntoList(s);
		assertEquals(editor.cur.data,'t');
		assertEquals(editor.curPos,0);
		editor.moveRight();
		assertEquals(editor.cur.data,'e');
		assertEquals(editor.curPos,1);
		editor.moveRight();
		assertEquals(editor.cur.data,'s');
		assertEquals(editor.curPos,2);
		editor.moveRight();
		assertEquals(editor.cur.data,'t');
		assertEquals(editor.curPos,3);
		editor.moveRight();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,4);
		editor.moveRight();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,4);
		editor.moveRight();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,4);
	
	}
	@Test
	void moveLeftTest() {
		Editor editor=new Editor();
		String s="test";
		editor.putIntoList(s);
		editor.moveLeft();
		editor.moveLeft();
		assertEquals(editor.cur.data,'t');
		assertEquals(editor.curPos,0);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveLeft();
		assertEquals(editor.cur.data,'t');
		assertEquals(editor.curPos,3);
		editor.moveLeft();
		assertEquals(editor.cur.data,'s');
		assertEquals(editor.curPos,2);
		editor.moveLeft();
		assertEquals(editor.cur.data,'e');
		assertEquals(editor.curPos,1);
		editor.moveLeft();
		assertEquals(editor.cur.data,'t');
		assertEquals(editor.curPos,0);
		editor.moveLeft();
		editor.moveLeft();
		assertEquals(editor.cur.data,'t');
		assertEquals(editor.curPos,0);

	}
	@Test
	void moveToHead() {
		Editor editor=new Editor();
		String s="A tests";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveToHead();
		assertEquals(editor.cur.data,'A');
		assertEquals(editor.curPos,0);
	}
	@Test
	void moveToHeadOneChar() {
		Editor editor=new Editor();
		String s="A";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveToHead();
		assertEquals(editor.cur.data,'A');
		assertEquals(editor.curPos,0);
		
	}
	@Test
	void moveToHeadOnHead() {
		Editor editor=new Editor();
		String s="A tests";
		editor.putIntoList(s);
		editor.moveToHead();
		assertEquals(editor.cur.data,'A');
		assertEquals(editor.curPos,0);
	}
	
	@Test
	void moveToHeadEmpty() {
		Editor editor=new Editor();
		String s="";
		editor.putIntoList(s);
		editor.moveToHead();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,0);
		
	}
	@Test
	void moveToTail() {
		Editor editor=new Editor();
		String s="A tests";
		editor.putIntoList(s);
		editor.moveToTail();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,7);
	}
	@Test
	void moveToTalOnTail() {
		Editor editor=new Editor();
		String s="A tests";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveToTail();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,7);
	}
	@Test
	void moveToTailEmpty() {
		Editor editor=new Editor();
		String s="";
		editor.putIntoList(s);
		editor.moveToHead();
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,0);
		
		
	}
	
	@Test
	void insertTest() {
		Editor editor=new Editor();
		String s="Hi Hello";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.insert('j');
		editor.insert('o');
		editor.insert('i');
		assertEquals(editor.toString(),"Hi Hjoiello");
		assertEquals(editor.numChars,11);
		assertEquals(editor.curPos,7);
	}
	
	@Test
	void insertHeadTest() {
		Editor editor=new Editor();
		String s="Hi Hello";
		editor.putIntoList(s);
		editor.insert('t');
		assertEquals(editor.toString(),"tHi Hello");
		assertEquals(editor.numChars,9);
		assertEquals(editor.curPos,1);
	}
	@Test
	void insertTailTest() {
		Editor editor=new Editor();
		String s="Hi";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.insert('a');
		assertEquals(editor.toString(),"Hia");
		assertEquals(editor.numChars,3);
		assertEquals(editor.curPos,3);
	}
	@Test 
	void insertOneChar(){
		Editor editor=new Editor();
		String s="H";
		editor.putIntoList(s);
		editor.moveRight();
		editor.insert('i');
		assertEquals(editor.toString(),"Hi");
		assertEquals(editor.numChars,2);
		assertEquals(editor.curPos,2);
	}
	@Test 
	void insertEmpty() {
		Editor editor=new Editor();
		editor.insert('i');
		editor.insert('t');
		assertEquals(editor.toString(),"it");
		assertEquals(editor.numChars,2);
		assertEquals(editor.curPos,2);
		assertEquals(editor.cur,null);
	}
	@Test
	void deleteTestHeadandTail(){
		Editor editor=new Editor();
		String s="Hi Hello";
		editor.putIntoList(s);
		editor.delete();
		assertEquals(editor.head.data,'i');
		assertEquals(editor.cur.data,'i');
		assertEquals(editor.numChars,7);
		assertEquals(editor.curPos,0);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.delete();
		assertEquals(editor.cur,null);
		assertEquals(editor.numChars,6);
		assertEquals(editor.tail.data,'l');
		
	}
	@Test
	void deleteTest() {
		Editor editor=new Editor();
		String s="Hi Hello";
		editor.putIntoList(s);
		editor.moveRight();
		editor.delete();
		assertEquals(editor.head.next.data,' ');
		assertEquals(editor.numChars,7);
		assertEquals(editor.curPos,1);
	}
	@Test 
	void backSpaceTestsHeadandTail() {
		Editor editor=new Editor();
		String s="Hi Hello";
		editor.putIntoList(s);
		editor.backspace();
		assertEquals(editor.head.data,'H');
		assertEquals(editor.numChars,8);
		assertEquals(editor.curPos,0);
		editor.moveRight();
		editor.backspace();
		assertEquals(editor.head.data,'i');
		assertEquals(editor.numChars,7);
		assertEquals(editor.curPos,0);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		editor.backspace();
		assertEquals(editor.tail.data,'l');
		assertEquals(editor.numChars,6);
		assertEquals(editor.curPos,6);
		assertEquals(editor.cur,null);
	}
	@Test 
	void backSpaceTests() {
		Editor editor=new Editor();
		String s="Hi Hello";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		assertEquals(editor.cur.data,'H');
		editor.backspace();
		assertEquals(editor.cur.data,'H');
		assertEquals(editor.head.next.next.data,'H');
		assertEquals(editor.numChars,7);
		assertEquals(editor.curPos,2);
	}
	@Test
	void clearTest() {
		Editor editor=new Editor();
		String s="test";
		editor.putIntoList(s);
		editor.clear();
		assertEquals(editor.head,null);
		assertEquals(editor.tail,null);
		assertEquals(editor.cur,null);
		assertEquals(editor.curPos,0);
		assertEquals(editor.numChars,0);
	}
	@Test 
	void Save() {
		Editor editor=new Editor();
		String s="test";
		editor.putIntoList(s);
		editor.save();
		editor.delete();
		editor.save();
		assertEquals(editor.savedVersions.top(),"est");
		assertEquals(editor.savedVersions.size(),2);
		editor.savedVersions.pop();
		assertEquals(editor.savedVersions.top(),"test");
	}
	@Test 
	void Undo() {
		Editor editor=new Editor();
		String s="test";
		editor.putIntoList(s);
		editor.save();
		editor.delete();
		editor.save();
		editor.undo();
		assertEquals(editor.savedVersions.top(),"test");
		assertEquals(editor.savedVersions.size(),1);
		editor.undo();
		editor.undo();
		editor.undo();
		assertEquals(editor.savedVersions.size(),0);
		assertTrue(editor.savedVersions.isEmpty());
	}
	@Test 
	void SaveAndUndo() {
		Editor editor=new Editor();
		editor.save();
		assertEquals(editor.savedVersions.top(),"");
		assertFalse(editor.savedVersions.isEmpty());
		String s="test";
		editor.putIntoList(s);
		editor.moveToTail();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		editor.insert('s');
		editor.save();
		assertEquals(editor.savedVersions.top(),"testsssssssssssss");
		assertEquals(editor.savedVersions.size(),14);
		assertFalse(editor.savedVersions.isEmpty());
		editor.undo();
		assertEquals(editor.savedVersions.top(),"testssssssssssss");
		assertEquals(editor.savedVersions.size(),13);
		editor.undo();
		assertEquals(editor.savedVersions.top(),"testsssssssssss");
		assertEquals(editor.savedVersions.size(),12);
		editor.undo();
		assertEquals(editor.savedVersions.top(),"testssssssssss");
		assertEquals(editor.savedVersions.size(),11);
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		editor.undo();
		assertTrue(editor.savedVersions.isEmpty());
		assertEquals(editor.savedVersions.size(),0);
		assertEquals(editor.savedVersions.top(),null);
	}
	@Test
	void undoEmpty() {
		Editor editor=new Editor();
		boolean thrown=false;
		try {
			editor.undo();
		}
		catch(IllegalStateException exception) {
			thrown=true;
		}
		assertFalse(thrown);
	}
	@Test
	void exportTest() {
		File f=new File ("file.txt");
		assertTrue(f.exists());
	}
	@Test 
	void toStringTest() {
		Editor editor=new Editor();
		String s="test";
		editor.putIntoList(s);
		editor.delete();
		assertEquals(editor.toString(),"est");
	}
	@Test 
	void getCursorPositionTest() {
		Editor editor=new Editor();
		String s="A tests";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		assertEquals(editor.getCursorPosition(),3);
	}
	
	@Test 
	void getSizeTest() {
		Editor editor=new Editor();
		String s="A tests";
		editor.putIntoList(s);
		editor.moveRight();
		editor.moveRight();
		editor.moveRight();
		assertEquals(editor.size(),7);
	}
	@Test
	void saveRepeatTest() {
		Editor editor=new Editor();
		String s="Tests";
		editor.putIntoList(s);
		editor.save();
		editor.delete();
		editor.insert('T');
		assertEquals(editor.toString(),"Tests");
		editor.save();
		assertEquals(editor.savedVersions.size(),1);
		editor.savedVersions.pop();
		assertTrue(editor.savedVersions.isEmpty());
		
	}
	

}
