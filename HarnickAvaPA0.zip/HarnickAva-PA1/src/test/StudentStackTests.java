package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import main.Stack;

class StudentStackTests {

	@Test
	void pushTestNotFull() {
		Stack<Integer>stack=new Stack <Integer>();
		stack.push(3);
		stack.push(4);
		stack.push(6);
		assertEquals(stack.size(),3);
		assertEquals(stack.pop(),6);
		assertEquals(stack.pop(),4);
		assertEquals(stack.pop(),3);
	}
	@Test
	void pushTestFull() {
		Stack<Integer>stack=new Stack <Integer>();
		stack.push(3);
		stack.push(4);
		stack.push(6);
		stack.push(7);
		stack.push(9);
		stack.push(0);
		stack.push(3);
		stack.push(4);
		stack.push(6);
		stack.push(7);
		stack.push(9);
		stack.push(0);
		stack.push(3);
		stack.push(4);
		stack.push(6);
		stack.push(7);
		stack.push(0);
		assertEquals(stack.size(),17);
		assertEquals(stack.pop(),0);
		assertEquals(stack.pop(),7);
		assertEquals(stack.pop(),6);
		assertEquals(stack.pop(),4);
		assertEquals(stack.pop(),3);
		assertEquals(stack.pop(),0);
		assertEquals(stack.pop(),9);
		assertEquals(stack.pop(),7);
		assertEquals(stack.pop(),6);
		assertEquals(stack.pop(),4);
		assertEquals(stack.pop(),3);
		
	}
	@Test
	void popTest() {
		Stack<Integer>stack=new Stack <Integer>();
		stack.push(3);
		stack.push(4);
		stack.push(6);
		assertEquals(stack.pop(),6);
		assertEquals(stack.size(),2);
		assertEquals(stack.pop(),4);
		assertEquals(stack.size(),1);
		assertEquals(stack.pop(),3);
		assertEquals(stack.size(),0);
	}
	@Test
	void popTestEmpty() {
		Stack<Integer>stack=new Stack <Integer>();
		boolean thrown=false;
		try {
			stack.pop();
		}catch(IllegalStateException exception){
			thrown=true;
		}
		assertTrue(thrown);
	}
	@Test
	void topTestEmpty() {
		Stack<Integer>stack=new Stack <Integer>();
		assertEquals(stack.top(),null);
	}
	@Test
	void topTest() {
		Stack<Integer>stack=new Stack <Integer>();
		stack.push(3);
		stack.push(4);
		assertEquals(stack.top(),4);
		stack.pop();
		assertEquals(stack.top(),3);
		stack.pop();
		assertEquals(stack.top(),null);
	}
	@Test
	void sizeTest() {
		Stack<Integer>stack=new Stack <Integer>();
		assertEquals(stack.size(),0);
		stack.push(3);
		assertEquals(stack.size(),1);
		stack.push(4);
		assertEquals(stack.size(),2);
		stack.pop();
		stack.pop();
		assertEquals(stack.size(),0);
	}
	@Test
	void isEmpltyTest() {
		Stack<Integer>stack=new Stack <Integer>();
		assertTrue(stack.isEmpty());
		stack.push(3);
		assertFalse(stack.isEmpty());
		stack.pop();
		assertTrue(stack.isEmpty());
	}
	@Test
	void toStringTest() {
		Stack<Integer>stack=new Stack <Integer>();
		assertEquals(stack.toString(),"");
		stack.push(5);
		assertEquals(stack.toString(),"5\n");
		stack.push(2);
		assertEquals(stack.toString(),"2\n5\n");
		stack.pop();
		assertEquals(stack.toString(),"5\n");
		stack.pop();
		assertEquals(stack.toString(),"");
	}
	
	
}
